--------------------REQUIREMENTS TO RUN THE CODE--------------------------

##########################################################################
1.PACKAGES

import requests
import tkinter
from tkinter import *
import json
from watson_developer_cloud import NaturalLanguageUnderstandingV1
from watson_developer_cloud.natural_language_understanding_v1 \
import Features, EntitiesOptions, KeywordsOptions
from watson_developer_cloud import ToneAnalyzerV3 as ta
from watson_developer_cloud import visual_recognition_v3 as vr
import os
import random
import webbrowser


2.THE INPUT OF NATURAL LANGUAGE PROCESSING AND TONE ANALYZER MUST BE GIVEN IN A TEXT FORMAT

3.THE PATH OF IMAGE TO BE ANALYZED USING VISUAL RECOGNITION MUST BE PROVIED 

4.FEW SONGS AND VIDEOS AND PDF of Quotes AS REMIDIES ARE ALREADY PROVIDED IN THE SAMPLE


GOOD LUCK AND WISH YOU A NICE DAY.

__________________________________________________________________________________________
#####-----------------------THANK YOU-----------------------------------------############

OUR TEAM

NAINA ROY(3rd year B.TECH CSE)
AMEETA SOM(3rd year B.TECH CSE)
SUDHNAYA GANDHI(3rd year B.TECH CSE)
ARNAB DAS(3rd year B.TECH CSE)